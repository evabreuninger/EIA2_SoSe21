"use strict";
var eia11_1;
(function (eia11_1) {
    class Animated {
        update() { }
        draw() { }
    }
    eia11_1.Animated = Animated;
})(eia11_1 || (eia11_1 = {}));
//# sourceMappingURL=animated.js.map