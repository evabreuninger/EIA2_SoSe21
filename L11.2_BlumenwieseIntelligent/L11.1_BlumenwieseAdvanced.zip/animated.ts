namespace eia11_1 {
    export abstract class Animated {
        update(): void {}
        draw(): void {}
    }
}