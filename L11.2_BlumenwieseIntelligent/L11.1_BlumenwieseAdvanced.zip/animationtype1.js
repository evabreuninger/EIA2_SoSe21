"use strict";
var eia11_1;
(function (eia11_1) {
    class AnimationType1 extends eia11_1.Animated {
        constructor(x, y, vX, vY) {
            super();
            this.x = x;
            this.y = y;
            this.vX = vX;
            this.vY = vY;
        }
    }
    eia11_1.AnimationType1 = AnimationType1;
})(eia11_1 || (eia11_1 = {}));
//# sourceMappingURL=animationtype1.js.map