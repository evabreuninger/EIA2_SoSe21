"use strict";
var eia11_1;
(function (eia11_1) {
    eia11_1.canvas = document.getElementById("canvas");
    eia11_1.c = eia11_1.canvas.getContext("2d");
})(eia11_1 || (eia11_1 = {}));
//# sourceMappingURL=init.js.map