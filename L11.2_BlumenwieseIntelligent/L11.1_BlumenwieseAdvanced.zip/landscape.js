"use strict";
var eia11_1;
(function (eia11_1) {
    class Landscape {
        constructor(x, y, height) {
            this.x = x;
            this.y = y;
            this.height = height;
        }
        draw() { }
    }
    eia11_1.Landscape = Landscape;
})(eia11_1 || (eia11_1 = {}));
//# sourceMappingURL=landscape.js.map