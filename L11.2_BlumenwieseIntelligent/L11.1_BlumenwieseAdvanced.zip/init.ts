namespace eia11_1 {
    export let canvas: HTMLCanvasElement = <HTMLCanvasElement> document.getElementById("canvas");
    export let c: CanvasRenderingContext2D = canvas.getContext("2d")!;
}
